DO NOT ATTEMPT TO INSTALL THIS INTO AN EXISTING INSTALLATION OF YOUR CMS, IT IS A FULL CMS INSTALLATION, NOT JUST THE JOMRES COMPONENT.

The is the Jomres Quickstart file. You will need to use kickstart.php to extract it.

Upload the .jpa and kickstart.php files to your site's root via ftp. This means, if your site (for example www.domain.com) is going to reside in /var/www/html, then upload these files to that directory. 

Once the files have been uploaded to your webserver point your web browser to your site and the kickstart.php file by visiting www.domain.com/kickstart.php and follow the on-screen instructions.

Creating this installation is a long process, therefore it is not possible to create a new version ever time Jomres is updated. As a result what you should do now is ensure that both the CMS and Jomres are up to date. You can do this with a few clicks. 

That's it, you're done, you can move on with configuring Jomres to suit your own requirements.


Kickstart documentation https://www.akeebabackup.com/documentation/akeeba-kickstart-documentation.html & video https://www.akeebabackup.com/videos/1508-abt06-restoring-to-new-server-using-kickstart.html

Akeeba backup is an excellent tool and we strongly recommend that you invest in a full subscription for the product via https://www.akeebabackup.com/ as it includes a great many tools and features not available in the free version included in this installation.

Kickstart/Akeeba/Admintools are not Woollyinwales IT products. They are part of the excellent suit of products from Nik at https://www.akeebabackup.com/ and copyright belongs to Nicholas K. Dionysopoulos / AkeebaBackup.com
